<?php /*fichier tool/php/php-bdd/connexion-pdo-req-simple.php 20190330-PBO */

/*ENTETE HTML ================================================================== */ ?>
<!DOCTYPE HTML> 

<html lang="fr">
<head>
<meta charset="utf-8" />
       <title>Login Verif TPNFA083</title>
       <meta name="description" content="DESCRIPTION" />	
		<link rel="stylesheet" href="css/styles.css">	   
</head> 
         
<body>

<?php 
	include ("./inc/Fonctions.php");
	?>
	<h1>Connexion Conseil Vente</h1>

<?php

$con=connectbd();
	$uname="";
	$username = $_POST['username'];
	$password = $_POST['password'];
	$requette="SELECT username FROM users WHERE username='$username' and password='$password'" ; /* Recherche username */
	$resultat = $con->query($requette);  
	
    While($donnees= $resultat->fetch())
	{ 
		$uname=$donnees['username'] ; 
			if($uname==$username){
			session_start();
			$_SESSION['username'] = $username;
			?><p> Bienvenue <?php echo $username; ?> </p> 
			<a href="logout.php">Déconnexion</a>
			<?php
			}
	}	
	if ($uname=="") {
			?><p>Le nom d'utilisateur ou le mot de passe est incorrect</p>
			<a href="Register.html">Retour Connexion</a> <?php
			}
?>
			


</body>
</html>    		