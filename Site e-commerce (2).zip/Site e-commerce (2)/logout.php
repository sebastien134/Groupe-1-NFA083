<?php
  include ("./inc/Fonctions.php");
  logout();
  header("location: register.html");
?>