<?php 

function logout(){
	// Initialiser la session
  session_start();
  
  // Détruire la session.
  if(session_destroy())
  {
    // Redirection vers la page de connexion
    header("Location: register.html");
  }
}

function connectbd(){
    $server = "localhost";  
	$serverlogin = "root";  
	$serverpassword = "";
	$dbname= "tpnfa083"; 

   try{                                                                /* essai de connexion              */
         $pdo_option[PDO::ATTR_ERRMODE]=PDO::ERRMODE_EXCEPTION;        /* Option Afficher les erreurs     */ 
		 $pdo_option[PDO::MYSQL_ATTR_INIT_COMMAND]='SET NAMES utf8';   /* Option caractères utf8          */ 
		 $con= new PDO('mysql:host='.$server.';dbname='.$dbname,$serverlogin,$serverpassword,$pdo_option); /*Connexion serveur et BDD     */
	} catch (PDOException $erreur) {    

	echo 'Echec lors de la connexion: ' .$erreur->getMessage();          /*Affiche l'éventuelle erreur       */
	} 
	return $con;
}

?>

